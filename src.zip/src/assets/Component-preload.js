//@ui5-bundle my-ui5-app/Component-preload.js
sap.ui.require.preload({
	"my-ui5-app/manifest.json":'{"_version":"1.21.0","sap.app":{"id":"my-ui5-app","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"1.0.0"},"title":"My UI5 App","description":"A simple SAP UI5 application","dataSources":{}},"sap.ui":{"technology":"UI5","icons":{"icon":"sap-icon://world"},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"rootView":{"viewName":"my-ui5-app.view.Main","type":"XML","id":"app"},"dependencies":{"minUI5Version":"1.60.0","libs":{"sap.m":{},"sap.ui.core":{}}},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"my-ui5-app.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]}}}'
});
//# sourceMappingURL=Component-preload.js.map
