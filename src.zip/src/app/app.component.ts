import { Component } from '@angular/core';

@Component({
  selector: 'ui5-ionic-app',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}
}




